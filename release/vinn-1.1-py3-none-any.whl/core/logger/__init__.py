from .Logger import init_logger, get_logger

init_logger()
log = get_logger()